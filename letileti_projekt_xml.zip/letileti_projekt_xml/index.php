<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css.css">

    
    <title>Leti-Leti</title>
</head>
<body>
<a name="top"></a>
    <header>
        <nav>
            <ul>
                <li><img src="logo1.svg" height="70"></li>
                <li><a href="#contact">Contact</a></li>
                <li><a href="#Meet">Meet the Pack</a></li>
                <li><a href="#Take">Care</a></li>
                <li><a href="#Puli">Puli</a></li>
              </ul>
        </nav>
    </header>

    

    <div class="flexrednaslov">
        <a name="Puli"></a>
        <h2>Hungarian Puli</h2>
    </div>
    <div class="flexa1">
        <div class='prvi'>
            <img src="img/mora.jpg" >
        </div>
    <div class='drugi'>
        <p>The Puli is a small-medium breed of Hungarian herding and livestock guarding dog known for its long, corded coat. The tight curls of the coat appear similar to dreadlocks. 
            A similar-looking, but much larger breed – also Hungarian – is the Komondor. 
            Plural form of Puli is Pulik in Hungarian.</p>
            <br>
        <p>
            The Puli is a solid-colored dog that is usually black. Other less common coat colors are white, gray, or cream (off-white or fakó in Hungarian). 
            A variety of the cream-coated dogs have black masks. 
            The white Pulis are not albino, nor do they have blue eyes. 
            They commonly have dark pigment, black pads, black noses and black pigment inside the mouth. 
            The white gene is recessive to the pure black gene. The breed standard for females is about 16.5 inches (42 cm) at the withers and 17 inches for males.
            Females weigh 23-25 pounds and males slightly more.</p>
    </div>
</div>



<div class="flexrednaslov">
        <a name="Take"></a>
        <h2>Taking Care of the Hungarian Puli</h2>
    </div>
    <div class="flexa1">

    <div class='lijevi'>
        <p>This dog's coat needs extra attention because it is corded. 
            As the puppy grows, the cords need to be separated so that they don't get 
            intertwined into a huge knot. Once the cords touch the ground, it needs to be 
            trimmed to prevent the Puli from tripping on its hair. 
            Their nails also need to be regularly trimmed. </p>

            <br>
        <p>
        Just like any other dog, the Hungarian Puli needs regular baths. 
        After a bath, however, you must take the time to dry their coat thoroughly, 
        and this may be time-consuming because their hair is so thick and twisted.</p>
        <br>
        <p>
        Remember to take the dog out every day for exercise. 
        The Hungarian Puli makes an excellent jogging partner. Despite its strength,
         cataracts and hip displacements can occur in the case of some dogs. 
         Check with the vet for necessary vaccinations. </p>

    </div>
    <div class='desni'>
            <img src="img/strastra.jpg" width="100%">
        </div>
    </div>





    <div class="flexrednaslov">
        <a name="Meet"></a>
        <h2>Meet the pack</h2>
    </div>  
    <div class="flexa1">
        <div id="novi"> 
        <?php
        $xmldata = simplexml_load_file("pack.xml") or die("Failed to load");
        foreach($xmldata->children() as $pas) {         
        echo '<img src="img/'.$pas->Image.'" height="500">'.'<br><br>'; 
         echo "Name: ".'<b>'.$pas->Name . '</b><br>';     
         echo "Nickame: ".'<b>'.$pas->Nickname . '</b><br>';        
         echo "Sex: ".'<b>'.$pas->Sex. '</b><br>';
         echo "Date of birth: ".'<b>'.$pas->Date . '</b><br>'; 
         echo "Color: ".'<b>'.$pas->Color . '</b><br>';     
         echo "Mother: ".'<b>'.$pas->Mother . '</b><br>';        
         echo "Father: ".'<b>'.$pas->Father. '</b><br><br>';
        } ?>
        </div>
    </div>
</div>


    <div class="flexrednaslov">
        <a name="contact"></a>
        <h2>Contact us!</h2>
    </div>
    <div class="flexa1">

    <div class='lijevi'>
    <div class="mapouter"><div class="gmap_canvas"><iframe width="600" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=velika%20gorica&t=k&z=15&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://fmovies-online.net"></a><br><style>.mapouter{position:relative;text-align:right;height:500px;width:600px;}</style><a href="https://www.embedgooglemap.net">google maps embed code generator</a><style>.gmap_canvas {overflow:hidden;background:none!important;height:500px;width:600px;}</style></div></div>
    </div>
    <div class='desni'>
    <p style="padding-left:60px;padding-top:35%;text-align:left;">
        Name: <b>Korina Cvijanović</b>
        <br><br>
        Adress: <b>Adresa 33, 10410 Velika Gorica</b>
        <br><br>
        Phone: <b>099 1234 567</b>
        <br><br>
        email: <b>kcvijanovic@tvz.hr</b>
        <br><br>
    </p>
        </div>
    </div>  

    <div class="flexrednaslov">
    <a href="#top" text-align=center>Back to top</a>
    </div>
    <footer>
        <nav>
            <ul>
            
                <li><img src="logo1.svg" height="70"></li>
                <li id="foot">2021/2022</li>
                <li id="foot">Informatički Dizajn</li>
                <li id="foot">©</li>
                <li id="foot">Korina Cvijanović</li>
              </ul>
        </nav>
    </footer>
</body>
</html>